import { Component } from '@angular/core';


@Component({
  selector: 'app-relatorio',
  standalone: true,
  imports: [],
  templateUrl: './relatorio.component.html',
  styleUrl: './relatorio.component.scss',
})
export class RelatorioComponent {
  constructor() {}


}
