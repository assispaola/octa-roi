export interface SaidaCalculo {
  economia?: number; // R$, arredondado
  roi?: number; // %, arredondado
  novasVendas?: number; // qtd inteira
  receita?: number; // R$, arredondado
}
